// Package types contains all of the structs for objects in Statping including services, hits, failures, Core, and others.
//
// More info on: https://github.com/hunterlong/statping
package types
