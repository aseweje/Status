// Package plugin contains the interfaces to build your own Golang Plugin that will receive triggers on Statping events.
package plugin
