// Package handlers contains the HTTP server along with the requests and routes. All HTTP related
// functions are in this package.
//
// More info on: https://github.com/hunterlong/statping
package handlers
